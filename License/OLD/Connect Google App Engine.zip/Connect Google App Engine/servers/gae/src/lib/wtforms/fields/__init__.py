from wtforms.fields.core import *

# Compatibility imports
from wtforms.fields.core import Label, Field, _unset_value, SelectFieldBase, Flags
